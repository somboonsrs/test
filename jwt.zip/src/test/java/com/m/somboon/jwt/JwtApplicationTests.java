//package com.m.somboon.jwt;
//
////import org.junit.jupiter.api.Test;
////import org.springframework.boot.test.context.SpringBootTest;
//
//import org.junit.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class JwtApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
