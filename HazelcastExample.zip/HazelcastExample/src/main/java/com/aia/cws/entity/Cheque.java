/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aia.cws.entity;

/**
 *
 * @author Krissana
 */
public class Cheque {
    private String docId;
    private String branchName;
    private String cheqDate2;
    private String cheqAmtStart;
    private String cheqAmtThai;
    private String datSys;
    private String cheqPayeeTitle;
    private String cheqPayeeFName;
    private String policyNo;
    private String dpDsk;
    private String userDept1;
    private String imagePath;

    public Cheque() {
    }

    public Cheque(String docId, String branchName, String cheqDate2, String cheqAmtStart, String cheqAmtThai, String datSys, String cheqPayeeTitle, String cheqPayeeFName, String policyNo, String dpDsk, String userDept1) {
        this(docId, branchName, cheqDate2, cheqAmtStart, cheqAmtThai, datSys, cheqPayeeTitle, cheqPayeeFName, policyNo, dpDsk, userDept1, "");
    }
    
    public Cheque(String docId, String branchName, String cheqDate2, String cheqAmtStart, String cheqAmtThai, String datSys, String cheqPayeeTitle, String cheqPayeeFName, String policyNo, String dpDsk, String userDept1, String imagePath) {
        this.docId = docId;
        this.branchName = branchName;
        this.cheqDate2 = cheqDate2;
        this.cheqAmtStart = cheqAmtStart;
        this.cheqAmtThai = cheqAmtThai;
        this.datSys = datSys;
        this.cheqPayeeTitle = cheqPayeeTitle;
        this.cheqPayeeFName = cheqPayeeFName;
        this.policyNo = policyNo;
        this.dpDsk = dpDsk;
        this.userDept1 = userDept1;
        this.imagePath = imagePath;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getCheqDate2() {
        return cheqDate2;
    }

    public void setCheqDate2(String cheqDate2) {
        this.cheqDate2 = cheqDate2;
    }

    public String getCheqAmtStart() {
        return cheqAmtStart;
    }

    public void setCheqAmtStart(String cheqAmtStart) {
        this.cheqAmtStart = cheqAmtStart;
    }

    public String getCheqAmtThai() {
        return cheqAmtThai;
    }

    public void setCheqAmtThai(String cheqAmtThai) {
        this.cheqAmtThai = cheqAmtThai;
    }

    public String getDatSys() {
        return datSys;
    }

    public void setDatSys(String datSys) {
        this.datSys = datSys;
    }

    public String getCheqPayeeTitle() {
        return cheqPayeeTitle;
    }

    public void setCheqPayeeTitle(String cheqPayeeTitle) {
        this.cheqPayeeTitle = cheqPayeeTitle;
    }

    public String getCheqPayeeFName() {
        return cheqPayeeFName;
    }

    public void setCheqPayeeFName(String cheqPayeeFName) {
        this.cheqPayeeFName = cheqPayeeFName;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getDpDsk() {
        return dpDsk;
    }

    public void setDpDsk(String dpDsk) {
        this.dpDsk = dpDsk;
    }

    public String getUserDept1() {
        return userDept1;
    }

    public void setUserDept1(String userDept1) {
        this.userDept1 = userDept1;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }        
}
