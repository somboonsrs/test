/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aia.cws.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 *
 * @author Krissana
 */
@Component
@PropertySource("classpath:report.properties")
@ConfigurationProperties
public class ReportProperties {
    private String reportTemplatePath;
    private String inputPath;
    private String outputPath;
    private String logPath;
    private String inputDataFile;
    private String inputFileEncoding;
    private String outputTempPath;
    private String outputDataFile;
    private String imagePath;

    public String getInputDataFile() {
        return inputDataFile;
    }

    public void setInputDataFile(String inputDataFile) {
        this.inputDataFile = inputDataFile;
    }

    public String getInputFileEncoding() {
        return inputFileEncoding;
    }

    public void setInputFileEncoding(String inputFileEncoding) {
        this.inputFileEncoding = inputFileEncoding;
    }

    public String getReportTemplatePath() {
        return reportTemplatePath;
    }

    public void setReportTemplatePath(String reportTemplatePath) {
        this.reportTemplatePath = reportTemplatePath;
    }

    public String getInputPath() {
        return inputPath;
    }

    public void setInputPath(String inputPath) {
        this.inputPath = inputPath;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }

    public String getLogPath() {
        return logPath;
    }

    public void setLogPath(String logPath) {
        this.logPath = logPath;
    }

    public String getOutputTempPath() {
        return outputTempPath;
    }

    public void setOutputTempPath(String outputTempPath) {
        this.outputTempPath = outputTempPath;
    }

    public String getOutputDataFile() {
        return outputDataFile;
    }

    public void setOutputDataFile(String outputDataFile) {
        this.outputDataFile = outputDataFile;
    }
    
    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }        
}
