/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aia.cws.entity;

/**
 *
 * @author Krissana
 */
public class Channel2 {
    private Integer seq;
    private String dstr1; 
    private String dstr2; 
    private String dstr3; 
    private String dstr4; 
    private String dstr5; 
    private String dstr6; 
    private String dstr7; 
    private String dstr8; 
    private String dstr9; 
    private String ddec1; 
    private String ddec2; 
    private String ddec3; 
    private String ddec4; 
    private String ddec5; 
    private String ddec6; 
    private String ddec7; 
    private String ddec8; 
    private String ddec9; 
    private String ddate10;
    private String ddate11;
    private String ddate12;
    private String ddate13;
    private String ddate14;
    private String ddate15;
    private String ddate16;
    private String ddate17;
    private String ddate18;
        
    public Channel2() {
    }    

    public Channel2(Integer seq, String dstr1, String dstr2, String dstr3, String dstr4, String dstr5, String dstr6, String dstr7, String dstr8, String dstr9, String ddec1, String ddec2, String ddec3, String ddec4, String ddec5, String ddec6, String ddec7, String ddec8, String ddec9, String ddate10, String ddate11, String ddate12, String ddate13, String ddate14, String ddate15, String ddate16, String ddate17, String ddate18) {
        this.seq = seq;
        this.dstr1 = dstr1;
        this.dstr2 = dstr2;
        this.dstr3 = dstr3;
        this.dstr4 = dstr4;
        this.dstr5 = dstr5;
        this.dstr6 = dstr6;
        this.dstr7 = dstr7;
        this.dstr8 = dstr8;
        this.dstr9 = dstr9;
        this.ddec1 = ddec1;
        this.ddec2 = ddec2;
        this.ddec3 = ddec3;
        this.ddec4 = ddec4;
        this.ddec5 = ddec5;
        this.ddec6 = ddec6;
        this.ddec7 = ddec7;
        this.ddec8 = ddec8;
        this.ddec9 = ddec9;
        this.ddate10 = ddate10;
        this.ddate11 = ddate11;
        this.ddate12 = ddate12;
        this.ddate13 = ddate13;
        this.ddate14 = ddate14;
        this.ddate15 = ddate15;
        this.ddate16 = ddate16;
        this.ddate17 = ddate17;
        this.ddate18 = ddate18;
    }

    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    
    public String getDstr1() {
        return dstr1;
    }

    public void setDstr1(String dstr1) {
        this.dstr1 = dstr1;
    }

    public String getDstr2() {
        return dstr2;
    }

    public void setDstr2(String dstr2) {
        this.dstr2 = dstr2;
    }

    public String getDstr3() {
        return dstr3;
    }

    public void setDstr3(String dstr3) {
        this.dstr3 = dstr3;
    }

    public String getDstr4() {
        return dstr4;
    }

    public void setDstr4(String dstr4) {
        this.dstr4 = dstr4;
    }

    public String getDstr5() {
        return dstr5;
    }

    public void setDstr5(String dstr5) {
        this.dstr5 = dstr5;
    }

    public String getDstr6() {
        return dstr6;
    }

    public void setDstr6(String dstr6) {
        this.dstr6 = dstr6;
    }

    public String getDstr7() {
        return dstr7;
    }

    public void setDstr7(String dstr7) {
        this.dstr7 = dstr7;
    }

    public String getDstr8() {
        return dstr8;
    }

    public void setDstr8(String dstr8) {
        this.dstr8 = dstr8;
    }

    public String getDstr9() {
        return dstr9;
    }

    public void setDstr9(String dstr9) {
        this.dstr9 = dstr9;
    }

    public String getDdec1() {
        return ddec1;
    }

    public void setDdec1(String ddec1) {
        this.ddec1 = ddec1;
    }

    public String getDdec2() {
        return ddec2;
    }

    public void setDdec2(String ddec2) {
        this.ddec2 = ddec2;
    }

    public String getDdec3() {
        return ddec3;
    }

    public void setDdec3(String ddec3) {
        this.ddec3 = ddec3;
    }

    public String getDdec4() {
        return ddec4;
    }

    public void setDdec4(String ddec4) {
        this.ddec4 = ddec4;
    }

    public String getDdec5() {
        return ddec5;
    }

    public void setDdec5(String ddec5) {
        this.ddec5 = ddec5;
    }

    public String getDdec6() {
        return ddec6;
    }

    public void setDdec6(String ddec6) {
        this.ddec6 = ddec6;
    }

    public String getDdec7() {
        return ddec7;
    }

    public void setDdec7(String ddec7) {
        this.ddec7 = ddec7;
    }

    public String getDdec8() {
        return ddec8;
    }

    public void setDdec8(String ddec8) {
        this.ddec8 = ddec8;
    }

    public String getDdec9() {
        return ddec9;
    }

    public void setDdec9(String ddec9) {
        this.ddec9 = ddec9;
    }

    public String getDdate10() {
        return ddate10;
    }

    public void setDdate10(String ddate10) {
        this.ddate10 = ddate10;
    }

    public String getDdate11() {
        return ddate11;
    }

    public void setDdate11(String ddate11) {
        this.ddate11 = ddate11;
    }

    public String getDdate12() {
        return ddate12;
    }

    public void setDdate12(String ddate12) {
        this.ddate12 = ddate12;
    }

    public String getDdate13() {
        return ddate13;
    }

    public void setDdate13(String ddate13) {
        this.ddate13 = ddate13;
    }

    public String getDdate14() {
        return ddate14;
    }

    public void setDdate14(String ddate14) {
        this.ddate14 = ddate14;
    }

    public String getDdate15() {
        return ddate15;
    }

    public void setDdate15(String ddate15) {
        this.ddate15 = ddate15;
    }

    public String getDdate16() {
        return ddate16;
    }

    public void setDdate16(String ddate16) {
        this.ddate16 = ddate16;
    }

    public String getDdate17() {
        return ddate17;
    }

    public void setDdate17(String ddate17) {
        this.ddate17 = ddate17;
    }

    public String getDdate18() {
        return ddate18;
    }

    public void setDdate18(String ddate18) {
        this.ddate18 = ddate18;
    }
    
}
