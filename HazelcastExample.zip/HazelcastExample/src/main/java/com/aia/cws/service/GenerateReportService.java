/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aia.cws.service;

import com.aia.cws.config.ReportProperties;
import com.aia.cws.entity.Cheque;
import com.aia.cws.entity.ChequeGenerateModel;
import com.aia.cws.entity.Channel2;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import com.hazelcast.core.MultiMap;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Krissana
 */
@Service
public class GenerateReportService {

    private static Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Autowired
    private HazelcastInstance hazelcastInstance;

    @Autowired
    private ReportProperties reportProperties;

    public static final String CHEQUE_MAP = "chequesData";
    public static final String ALIGNMENT_MAP = "alignmentData";
    public static final String CHEQUE_DET_MAP = "chequeDetsData";
    public static final String REPORT_MAP = "reportsData";
    
    public static final int MAX_CASPAY_RECORD = 9;
    public static final int MAX_EOB_RECORD = 13;
    public static final int MAX_SEQUENCE_CASPAY = 10;
    public static final int MAX_SEQUENCE_EOB = 14;
    public static final int MIN_LINE_LENGTH = 2;
  
    private boolean bStartedMerge = false;    
    private boolean isLoadedData = false; 

    private PDDocument pdfDes = null;
    private PDFMergerUtility pdfUtil = new PDFMergerUtility();

    // Config to distribute process
    // Map instance to keep datasource information
    private Map<Integer, String> chequeMap;

    // Map instance to keep alignment data
    private Map<Integer, String> alignmentMap;
    
    // Map instance to keep datasource channel2
    private MultiMap<Integer, String> chequeDetailMap;
    
    // Map instance to keep process report status
    private Map<String, ChequeGenerateModel> reportMap;
            
    public void loadData() throws FileNotFoundException, IOException, Exception {
        String inputDataFile = reportProperties.getInputPath() + "/" + reportProperties.getInputDataFile();
        String encoding = reportProperties.getInputFileEncoding();
        
        chequeMap = hazelcastInstance.getMap(CHEQUE_MAP);
        alignmentMap = hazelcastInstance.getMap(ALIGNMENT_MAP);
        chequeDetailMap = hazelcastInstance.getMultiMap(CHEQUE_DET_MAP);
        
        logger.info("===== AlignmentMap Map size: " + alignmentMap.size() + " =====");
        logger.info("===== Cheque Map size: " + chequeMap.size() + " =====");        
        logger.info("===== Cheque Detail Map size: " + chequeDetailMap.size() + " =====");
        //logger.info("===== Report Map size: " + reportMap.size() + " =====");

        // Counter for loaded item
        int itemCounter = 0;
        int alignmentCounter = 1;
        int seqChannel2Counter = 1;

        // String to keep information from text datasource
        String line;

        logger.info("===== Data file: " + inputDataFile + " =====");

        // Loop to read file line by line and insert to map
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputDataFile), encoding))) {
        //try (BufferedReader br = new BufferedReader(new FileReader(inputDataFile))) {
            while ((line = br.readLine()) != null) {

                if (line.startsWith("1 ") && line.startsWith("1 ***!")) {
                    // Insert alignment line to map                 
                    alignmentMap.put(alignmentCounter, line);
                    alignmentCounter++;
                }
                else if (line.startsWith("1 ") && !line.startsWith("1 ***!")) {
                    // Increase counter
                    itemCounter++;
                    
                    // Insert line to map
                    chequeMap.put(itemCounter, line);
                    
                    // For skip arrignment line
                    isLoadedData = true;
                    seqChannel2Counter = 1;
                }
                else if ((line.startsWith("2 ") || line.startsWith("  ")) && line.length() > MIN_LINE_LENGTH && isLoadedData) {
                    // Insert line to multiMap (channel2)
                    chequeDetailMap.put(itemCounter, seqChannel2Counter+"::"+line);
                    
                    seqChannel2Counter++;
                    //logger.debug("---- Store in " + itemCounter);
                }                
            }

            logger.info("===== Total map size: " + chequeMap.size() + " - cnt: " + itemCounter + " =====");
            logger.info("===== Total map (alignment) size: " + alignmentMap.size() + " =====");
            logger.info("===== Total map (channel2) size: " + chequeDetailMap.size() + " =====");

        } catch (FileNotFoundException ex) {
            logger.error("Caught an exception [loadData]: " + ex.getMessage(), ex);
            throw ex;
        } catch (IOException ex) {
            logger.error("Caught an exception [loadData]: " + ex.getMessage(), ex);
            throw ex;
        } catch (Exception ex) {
            logger.error("Caught an exception [loadData]: " + ex.getMessage(), ex);
            throw ex;
        }
    }

    public String process() throws Exception {
        IMap<Integer, String> map = hazelcastInstance.getMap(CHEQUE_MAP);
        Map<String, ChequeGenerateModel> statusMap = hazelcastInstance.getMap(REPORT_MAP);

        boolean isError = false;
        int itemCounter = 1;
        for (int key : map.localKeySet()) {
            String data = map.get(key);

            try {
                String[] inputData = data.split("!", -1);                                             
                byte[] pdfStreamData = generatePDFStream(inputData, key);
                //byte[] pdfStreamData = generatePDFStream(inputData, itemCounter);
                
                statusMap.put(inputData[83], new ChequeGenerateModel("done", pdfStreamData));
                //statusMap.put(""+itemCounter, new ChequeGenerateModel("done", pdfStreamData));                                
                
                itemCounter++;

            } catch (FileNotFoundException | JRException e) {
                statusMap.put("" + itemCounter, new ChequeGenerateModel("error:" + e.getMessage(), null));
                isError = true;
            } finally {
                //
            }
        }

        return (isError) ? "error" : "done";
    }

    public void mergePDFReport() throws Exception {
        // Get alignmentMap to alignMap                
        // Sort alignment PDF file by key with TreeMap
        TreeMap<Integer, String> alignmentResult = new TreeMap<>(hazelcastInstance.getMap(ALIGNMENT_MAP));
        
        reportMap = hazelcastInstance.getMap(REPORT_MAP);
        logger.debug("===== Result report map size: " + reportMap.size() + " =====");

        // Loop to print out error for debugging
        for (ChequeGenerateModel state : reportMap.values()) {
            if (state.getStatus().startsWith("error")) {
                logger.debug(">>>>> " + state.getStatus());
            }
        }
        
        // Sort result PDF file by key with TreeMap
        TreeMap<String, ChequeGenerateModel> sortedMapResult = new TreeMap<>(reportMap);
                
        // Remove map items and make it eligible for GC
        clearMap();

        logger.info("====== Clear working map done! ======");
        logger.info("====== Result sorted map size: " + sortedMapResult.size() + " ======");

        try {
//            if ((sortedResult == null) || (sortedResult.size() <= 0)) {
//                throw new Exception("PDF list is empty");
//            }

            // Start merge alignment pdf            
            for (int key : alignmentResult.keySet()) {
                String data = alignmentResult.get(key);
                
                //logger.debug(data);                
                String[] alignmentData = data.split("!", -1);                                             
                loadPDFMerge(generatePDFStream(alignmentData, key));                
            }
            logger.info("====== Merge alignment done ======");
            
            int mergeNo = 0;
            for (String key : sortedMapResult.keySet()) {
                loadPDFMerge(sortedMapResult.get(key).getContent());
                
//                byte[] pdf = sortedResult.get(key).getContent();
//
//                PDDocument doc = null;
//                try {
//                    if (bStartedMerge) {
//                        doc = PDDocument.load(pdf);
//                        pdfUtil.appendDocument(pdfDes, doc);
//                    } else {
//                        InputStream targetStream = new ByteArrayInputStream(pdf);
//                        pdfDes = PDDocument.load(targetStream, MemoryUsageSetting.setupMixed(500 * 1024 * 1024));
//                        //pdfDes = PDDocument.load(targetStream, MemoryUsageSetting.setupTempFileOnly());
//                        bStartedMerge = true;
//                    }
//                } catch (IOException e) {
//                    logger.error("PDFMergeStream loop " + e.getMessage(), e);
//                } finally {
//                    if (doc != null) {
//                        doc.close();
//                        doc = null;
//                    }
//                }

                mergeNo++;
            }

            savePDFMerge();
            logger.info("====== Merge files = " + mergeNo + " ======");

        } catch (Exception e) {
            logger.error("PDFMergeStream " + e.getMessage(), e);
            throw e;
        } finally {
            //
        }
    }
    
    public void loadPDFMerge(byte[] pdf) throws Exception {
        PDDocument doc = null;
        try {
            if (bStartedMerge) {
                doc = PDDocument.load(pdf);
                pdfUtil.appendDocument(pdfDes, doc);
            } else {
                InputStream targetStream = new ByteArrayInputStream(pdf);
                pdfDes = PDDocument.load(targetStream, MemoryUsageSetting.setupMixed(500 * 1024 * 1024));
                //pdfDes = PDDocument.load(targetStream, MemoryUsageSetting.setupTempFileOnly());
                bStartedMerge = true;
            }
        } catch (IOException e) {
            logger.error("LoadPDFMerge in MergePDFReport loop " + e.getMessage(), e);
            throw e;
        } finally {
            if (doc != null) {
                doc.close();
                doc = null;
            }
        }        
    }
    
    public void savePDFMerge() throws Exception {
        if (pdfDes == null) {
            throw new Exception("===== PDF Destination is null =====");
        }

        String exportFile = reportProperties.getOutputPath() + "/" + reportProperties.getOutputDataFile();;        
        pdfDes.save(exportFile);

        try {
            if (pdfDes != null) {
                pdfDes.close();
            }
        } catch (IOException ioe) {
            logger.error("SavePDFMerge " + ioe.getMessage(), ioe);
            throw ioe;
        }
    }

    /**
     * Reset map before and after processing to prevent malfunction process and
     * memory leak
     */
    private void clearMap() {
        // Get map instance from Hazelcast instance
        chequeMap = hazelcastInstance.getMap(CHEQUE_MAP);
        reportMap = hazelcastInstance.getMap(REPORT_MAP);
        alignmentMap = hazelcastInstance.getMap(ALIGNMENT_MAP);
        chequeDetailMap = hazelcastInstance.getMultiMap(CHEQUE_DET_MAP);

        // Clear it
        chequeMap.clear();       
        reportMap.clear();
        alignmentMap.clear();
        chequeDetailMap.clear();

        // Make it eligible for GC
        chequeMap = null;        
        reportMap = null;
        alignmentMap = null;
        chequeDetailMap = null;
    }

    public void shutdown() {
        hazelcastInstance.shutdown();
    }
    
    protected byte[] generatePDFStream(String[] inputData, int key) throws JRException, FileNotFoundException {
    //protected byte[] generatePDFStream(String[] inputData, int runNo) throws JRException, FileNotFoundException {
        byte[] pdfStream = null;

        MultiMap<Integer, String> multiMap = hazelcastInstance.getMultiMap(CHEQUE_DET_MAP);       
        
        String templateName = "";
        String chequeSeqNo = "";
        String docName = "";
        String imagePath = reportProperties.getImagePath();
        Map<String, Object> reportParam = null;

        try {
            reportParam = new HashMap<>();
            reportParam.put("companyId", inputData[0]);
            reportParam.put("docId", inputData[1]);
            reportParam.put("policyNo", inputData[2]);
            reportParam.put("cheqAmt", inputData[3].replaceAll(",", ""));
            reportParam.put("cheqAmtStart", inputData[4]);
            reportParam.put("cheqAmtThai", inputData[5]);
            reportParam.put("matchIndc", inputData[6]);
            reportParam.put("sourceCode", inputData[7]);
            reportParam.put("stateCode", inputData[8]);
            reportParam.put("disbTypeCode", inputData[9]);
            reportParam.put("dpDsk", inputData[10]);
            reportParam.put("bankCode", inputData[11]);
            reportParam.put("branchName", inputData[12]);
            reportParam.put("cheqDate", inputData[13]);
            reportParam.put("cheqDescLn1", inputData[14]);
            reportParam.put("cheqDescLn2", inputData[15]);
            reportParam.put("cheqDescLn3", inputData[16]);
            reportParam.put("cheqDescLn4", inputData[17]);
            reportParam.put("cheqPayeeTitle", inputData[18]);
            reportParam.put("cheqPayeeFName", inputData[19]);
            reportParam.put("cheqPayeeLName", inputData[20]);
            reportParam.put("zipCode", inputData[21]);
            reportParam.put("payeeAddrLn1", inputData[22]);
            reportParam.put("payeeAddrLn2", inputData[23]);
            reportParam.put("payeeAddrLn3", inputData[24]);
            reportParam.put("payeeAddrLn4", inputData[25]);
            reportParam.put("paymentType", inputData[26]);
            reportParam.put("prtxSeqNo", inputData[27]);
            reportParam.put("agencyOfficeCode1", inputData[28]);
            reportParam.put("agencyCode1", inputData[29]);
            reportParam.put("agencyCode2", inputData[30]);
            reportParam.put("agentCode1", inputData[31]);
            reportParam.put("agentCode2", inputData[32]);
            reportParam.put("docSc", inputData[33]);
            reportParam.put("cheqRelDate", inputData[34]);
            reportParam.put("insuredChq", inputData[35]);
            reportParam.put("cheqRunningNo", inputData[36]);
            reportParam.put("userID1", inputData[37]);
            reportParam.put("userDept1", inputData[38]);
            reportParam.put("letterDate", inputData[39]);    
            reportParam.put("insuredTitle", inputData[40]);
            reportParam.put("insuredName", inputData[41]);
            reportParam.put("insuredSuffix", inputData[42]);
            reportParam.put("ownerTitle", inputData[43]);
            reportParam.put("ownerName", inputData[44]);
            reportParam.put("ownerSuffix", inputData[45]);
            reportParam.put("ownerAddr1", inputData[46]);
            reportParam.put("ownerAddr2", inputData[47]);
            reportParam.put("ownerAddr3", inputData[48]);
            reportParam.put("ownerAddr4", inputData[49]);
            reportParam.put("corrType", inputData[50]);
            reportParam.put("char1", inputData[51]);
            reportParam.put("char2", inputData[52]);
            reportParam.put("char3", inputData[53]);
            reportParam.put("char4", inputData[54]);
            reportParam.put("str1", inputData[55]);
            reportParam.put("str2", inputData[56]);
            reportParam.put("str3", inputData[57]);
            reportParam.put("str4", inputData[58]);
            reportParam.put("str5", inputData[59]);
            reportParam.put("str6", inputData[60]);
            reportParam.put("str7", inputData[61]);
            reportParam.put("str8", inputData[62]);
            reportParam.put("str9", inputData[63]);
            reportParam.put("lstr1", inputData[64]);
            reportParam.put("lstr2", inputData[65]);
            reportParam.put("lstr3", inputData[66]);
            reportParam.put("lstr4", inputData[67]);
            reportParam.put("dec1", inputData[68].replaceAll(",", ""));
            reportParam.put("dec2", inputData[69].replaceAll(",", ""));
            reportParam.put("dec3", inputData[70].replaceAll(",", ""));
            reportParam.put("dec4", inputData[71].replaceAll(",", ""));
            reportParam.put("dec5", inputData[72].replaceAll(",", ""));
            reportParam.put("dec6", inputData[73].replaceAll(",", ""));
            reportParam.put("dec7", inputData[74].replaceAll(",", ""));
            reportParam.put("dec8", inputData[75].replaceAll(",", ""));
            reportParam.put("dec9", inputData[76].replaceAll(",", ""));
            reportParam.put("date1", inputData[77]);
            reportParam.put("date2", inputData[78]);
            reportParam.put("date3", inputData[79]);
            reportParam.put("date4", inputData[80]);
            reportParam.put("cheqDate2", inputData[81]);
            reportParam.put("datSys", inputData[82]);
            
            if (inputData.length > 83) {
                reportParam.put("cheqSeqNo", inputData[83]);
                reportParam.put("titleIndc", inputData[84]);
                reportParam.put("subOfficeCode", inputData[85]);
                reportParam.put("payeeType", inputData[86]);
                reportParam.put("distributeInd", inputData[87]);
                reportParam.put("dec10", inputData[88].replaceAll(",", ""));
                
                chequeSeqNo = inputData[83];
            }
            
            // cycleDate = cheqDate
            // agencyCode = agencyCode1
            // agentCode = agentCode1
            reportParam.put("cycleDate", inputData[13]);
            reportParam.put("agencyCode", inputData[29]);            
            reportParam.put("agentCode", inputData[31]);   
                       
            // Add ImagePath
            reportParam.put("imagePath", imagePath);

            List<Cheque> listOfCheque = new ArrayList<>();
            listOfCheque.add(new Cheque(inputData[1], inputData[12], inputData[81], inputData[4], inputData[5], inputData[82], inputData[18], inputData[19], inputData[2], inputData[10], inputData[38], imagePath));
            
            // Add listOfCheque for All SubReport
            reportParam.put("listOfCheque", listOfCheque);

            // This block for some report use Channel2 data as CASPAY, EOBEN, EOBTH, CFREF   
            if ("CASPAY".equals(inputData[1]) || "EOBEN".equals(inputData[1]) || "EOBTH".equals(inputData[1])) {
                //logger.debug("---- Get multiMap in : " + key);
                
                // add listOfDetail for CASPAY, EOB SubReport                                
                List<Channel2> listOfDetail = getChannel2(multiMap.get(key), inputData[1]);           
                reportParam.put("listOfDetail", listOfDetail);
            }
            else if ("CFREF".equals(inputData[1])) {
                String dstr1 = getDstr1(multiMap.get(key));
                reportParam.put("dstr1", dstr1);
            }
            else if ("*****".equals(inputData[1])) {
                templateName = "ShortCheque";
            }

            // This block for Select ShortCheque or ShortCheque LFCM
            // Select Report Template by docId, matchIndc, datSys
            if ("Y".equals(inputData[6])) {
                // template as docId
                templateName = inputData[1];
            } else {
                // Check datSys = LFCM 
                if ("LFCM".equals(inputData[82])) {
                    // template as ShortChequeLFCM
                    templateName = "ShortChequeLFCM";
                } else {
                    // template as ShortCheque
                    templateName = "ShortCheque";
                }
            }

            if ("ILWTH".equals(inputData[1]) || "ILFLC".equals(inputData[1]) || "ILSUR".equals(inputData[1]) || "NGWTH".equals(inputData[1]) || 
                "NGFLC".equals(inputData[1]) || "NGSUR".equals(inputData[1]) || "ILASR".equals(inputData[1]) || "NGASR".equals(inputData[1])) {
                
                // Use ILREF Template
                templateName = "ILREF";
            }             
            
            // Define docName by docId, matchIndc
            if ("Y".equals(inputData[6])) { 
                if ("ILWTH".equals(inputData[1]) || "ILFLC".equals(inputData[1]) || "ILSUR".equals(inputData[1]) || "NGWTH".equals(inputData[1]) || 
                    "NGFLC".equals(inputData[1]) || "NGSUR".equals(inputData[1]) || "ILASR".equals(inputData[1]) || "NGASR".equals(inputData[1])) {                
                    docName = "ILREF";
                } 
                else {
                    if ("CMICK".equals(inputData[1])) {          
                        docName = "CMICK";
                    } 
                    else {
                        docName = "00000";
                    }
                }  
            }
            else {
                docName = inputData[1];
            }
            // Add docName
            reportParam.put("docName", docName);  
            
            // Add data to dataSource
            List<Map<String, Object>> dataSource = new ArrayList<>();
            dataSource.add(reportParam);
           
            logger.info("++++ Call Jasper Report for ChequeSeqNo = " + chequeSeqNo + ", DocId = " + inputData[1] + " ++++"); 
            //logger.info("++++ Call Jasper Report for ChequeSeqNo = " + runNo + ", DocId = " + inputData[1] + " ++++");

            // Do Jasper Report
            String templatePath = reportProperties.getReportTemplatePath() + "/";
            String reportTemplate = reportProperties.getReportTemplatePath() + "/" + templateName + "Report.jasper";

            // Add Parameter
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("SUBREPORT_DIR", templatePath);
            
            // Genererate Report To PDF Stream
            JRDataSource jrDataSource = new JRBeanCollectionDataSource(dataSource);
            JasperPrint jasperPrint = JasperFillManager.fillReport(new FileInputStream(reportTemplate), parameters, jrDataSource);
            ByteArrayOutputStream pdfReport = new ByteArrayOutputStream();
            JasperExportManager.exportReportToPdfStream(jasperPrint, pdfReport);
            pdfStream = pdfReport.toByteArray();

        } catch (JRException | FileNotFoundException ex) {
            logger.error("Caught an exception [CheqeSeqNo=" + chequeSeqNo + ", DocId = " + inputData[1] + "]: ", ex);
            throw ex;
        }

        return pdfStream;
    }
        
    protected List<Channel2> getChannel2(Collection<String> values, String docId) {
        List<Channel2> tmpListOfDetail = new ArrayList<>();
        List<Channel2> listOfDetail = new ArrayList<>();
        
        double sumDec1 = 0.0;
        double sumDec2 = 0.0;
        double sumDec3 = 0.0;
        double sumDec4 = 0.0;
        double sumDec5 = 0.0;
        double sumDec6 = 0.0;
        double sumDec7 = 0.0;
        double sumDec8 = 0.0;
        double sumDec9 = 0.0;
        
        // Initial listOfDetail
        for (String data : values) {
            String[] channel2 = data.split("!", -1);
            
//            logger.debug("==================== dstr1 " + channel2[0]);
//            logger.debug("==================== dstr2 " + channel2[1]);
//            logger.debug("==================== dstr3 " + channel2[2]);
//            logger.debug("==================== dstr4 " + channel2[3]);
//            logger.debug("==================== dstr5 " + channel2[4]);
//            logger.debug("==================== dstr6 " + channel2[5]);
//            logger.debug("==================== dstr7 " + channel2[6]);
//            logger.debug("==================== dstr8 " + channel2[7]);
//            logger.debug("==================== dstr9 " + channel2[8]);
//            logger.debug("==================== ddec1 " + channel2[9]);
//            logger.debug("==================== ddec2 " + channel2[10]);
//            logger.debug("==================== ddec3 " + channel2[11]);
//            logger.debug("==================== ddec4 " + channel2[12]);
//            logger.debug("==================== ddec5 " + channel2[13]);
//            logger.debug("==================== ddec6 " + channel2[14]);
//            logger.debug("==================== ddec7 " + channel2[15]);
//            logger.debug("==================== ddec8 " + channel2[16]);
//            logger.debug("==================== ddec9 " + channel2[17]);
//            logger.debug("==================== ddate10 " + channel2[18]);
//            logger.debug("==================== ddate11 " + channel2[19]);
//            logger.debug("==================== ddate12 " + channel2[20]);
//            logger.debug("==================== ddate13 " + channel2[21]);
//            logger.debug("==================== ddate14 " + channel2[22]);
//            logger.debug("==================== ddate15 " + channel2[23]);
//            logger.debug("==================== ddate16 " + channel2[24]);
//            logger.debug("==================== ddate17 " + channel2[25]);
//            logger.debug("==================== ddate18 " + channel2[26]);  
//            logger.debug("============================================");
            
            sumDec1 += ((channel2[9] != null && !"".equals(channel2[9])) ? Double.parseDouble(channel2[9].replaceAll(",", "")) : 0.0);
            sumDec2 += ((channel2[10] != null && !"".equals(channel2[10])) ? Double.parseDouble(channel2[10].replaceAll(",", "")) : 0.0);
            sumDec3 += ((channel2[11] != null && !"".equals(channel2[11])) ? Double.parseDouble(channel2[11].replaceAll(",", "")) : 0.0);
            sumDec4 += ((channel2[12] != null && !"".equals(channel2[12])) ? Double.parseDouble(channel2[12].replaceAll(",", "")) : 0.0);
            sumDec5 += ((channel2[13] != null && !"".equals(channel2[13])) ? Double.parseDouble(channel2[13].replaceAll(",", "")) : 0.0);
            sumDec6 += ((channel2[14] != null && !"".equals(channel2[14])) ? Double.parseDouble(channel2[14].replaceAll(",", "")) : 0.0);
            sumDec7 += ((channel2[15] != null && !"".equals(channel2[15])) ? Double.parseDouble(channel2[15].replaceAll(",", "")) : 0.0);
            sumDec8 += ((channel2[16] != null && !"".equals(channel2[16])) ? Double.parseDouble(channel2[16].replaceAll(",", "")) : 0.0);
            sumDec9 += ((channel2[17] != null && !"".equals(channel2[17])) ? Double.parseDouble(channel2[17].replaceAll(",", "")) : 0.0);
            
            String seq = channel2[0].substring(0, channel2[0].indexOf("::"));
            String dstr1 = channel2[0].substring(channel2[0].indexOf(" ")+1);
            
            tmpListOfDetail.add(new Channel2(Integer.parseInt(seq), dstr1, channel2[1], channel2[2], channel2[3], channel2[4], channel2[5], channel2[6], channel2[7], channel2[8], 
                    channel2[9].replaceAll(",", ""), channel2[10].replaceAll(",", ""), channel2[11].replaceAll(",", ""), channel2[12].replaceAll(",", ""), 
                    channel2[13].replaceAll(",", ""), channel2[14].replaceAll(",", ""), channel2[15].replaceAll(",", ""), channel2[16].replaceAll(",", ""), channel2[17].replaceAll(",", ""), 
                    channel2[18], channel2[19], channel2[20], channel2[21], channel2[22], channel2[23], channel2[24], channel2[25], channel2[26]));            
        }
        
        // Sorting listOfDetail
        Collections.sort(tmpListOfDetail, new Comparator<Channel2>() {
            @Override
            public int compare(Channel2 o1, Channel2 o2) {
                return o1.getSeq().compareTo(o2.getSeq());
            }
        });
        
        // Default maxRecords = MAX_EOB_RECORD
        // maxSequence = null
        int maxRecords = MAX_EOB_RECORD;
        Integer maxSequence = null;
        String dstr1 = "";
        String dstr2 = ("EOBTH".equals(docId)) ? "รวม" : "Summary";
        
        // Change maxRecords, maxSequence
        if ("CASPAY".equals(docId)) {
            maxRecords = MAX_CASPAY_RECORD;
            maxSequence = MAX_SEQUENCE_CASPAY;
            dstr1 = "ยอดรวมทั้งหมด";
            dstr2 = "";
        }
        
        // Copy tmpListOfDetail to listOfDetail by sorted partiail                
        int countRecord = 1;
        for (Channel2 channelData : tmpListOfDetail) {
            listOfDetail.add(channelData);
            
            countRecord++;
            if (countRecord > maxRecords) {
                break;
            }            
        }        
        if (listOfDetail.size() > 0) {
            listOfDetail.add(new Channel2(maxSequence, dstr1, dstr2, "", "", "", "", "", "", "",
                        ""+sumDec1, ""+sumDec2, ""+sumDec3, ""+sumDec4, ""+sumDec5, ""+sumDec6, ""+sumDec7, ""+sumDec8, ""+sumDec9, 
                        "", "", "", "", "", "", "", "", ""));
        }
        
        return listOfDetail;
    }
    
    protected String getDstr1(Collection<String> values) {
        String dstr1 = "";
        for (String data : values) {
            String[] channel2 = data.split("!", -1);
            dstr1 = channel2[0].substring(2);
        }
        
        return dstr1;
    }
    
    public void testMultipMap() {
        // Create multimap to store key and values
        // MultiMap multiMap = new MultiValueMap();
        
        MultiMap<Integer, String> map = hazelcastInstance.getMultiMap("map");

        map.put(1, "1");
        map.put(1, "2");
        map.put(2, "3");
        System.out.printf("PutMember:Done");

        for (Integer key: map.keySet()){
            Collection<String> values = map.get(key);
            System.out.printf("%s -> %s\n", key, values);
        }        
    }
}
