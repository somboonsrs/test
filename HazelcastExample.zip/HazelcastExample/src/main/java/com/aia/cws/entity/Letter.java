/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aia.cws.entity;

import java.util.List;

/**
 *
 * @author Krissana
 */
public class Letter {

    private String companyId;
    private String docId;
    private String policyNo;
    private String cheqAmt;
    private String cheqAmtStart;
    private String cheqAmtThai;
    private String matchIndc;
    private String sourceCode;
    private String stateCode;
    private String disbTypeCode;
    private String dpDSk;
    private String bankCode;
    private String branchName;
    private String cheqDate;
    private String cheqDescLn1;
    private String cheqDescLn2;
    private String cheqDescLn3;
    private String cheqDescLn4;
    private String cheqPayeeTitle;
    private String cheqPayeeFname;
    private String cheqPayeeLname;
    private String zipCode;
    private String payeeAddrLn1;
    private String payeeAddrLn2;
    private String payeeAddrLn3;
    private String payeeAddrLn4;
    private String paymentType;
    private String prtxSeqNo;
    private String agencyOfficeCode1;
    private String agencyCode1;
    private String agencyCode2;
    private String agentCode1;
    private String agentCode2;
    private String docSc;
    private String cheqRelDate;
    private String insuredChq;
    private String cheqRunningNo;
    private String userID1;
    private String userDept1;
    private String letterDate;
    private String insuredTitle;
    private String insuredName;
    private String insuredSuffix;
    private String ownerTitle;
    private String ownerName;
    private String ownerSuffix;
    private String ownerAddr1;
    private String ownerAddr2;
    private String ownerAddr3;
    private String ownerAddr4;
    private String corrType;
    private String char1;
    private String char2;
    private String char3;
    private String char4;
    private String str1;
    private String str2;
    private String str3;
    private String str4;
    private String str5;
    private String str6;
    private String str7;
    private String str8;
    private String str9;
    private String lstr1;
    private String lstr2;
    private String lstr3;
    private String lstr4;
    private String dec1;
    private String dec2;
    private String dec3;
    private String dec4;
    private String dec5;
    private String dec6;
    private String dec7;
    private String dec8;
    private String dec9;
    private String date1;
    private String date2;
    private String date3;
    private String date4;
    private String cheqDate2;
    private String datSys;
    private String cheqSeqNo;
    private String titleIndc;
    private String subOfficeCode;
    private String payeeType;
    private String distributeInd;
    private String dec10;
    
    private String cycleDate;
    private String optStr;

    private List<Cheque> listOfCheque;
    
    public Letter() {
    }
    
    public Letter(String[] inputData) {
        this(inputData, null);
    }
    
    public Letter(String[] inputData, String optStr) {
        this.companyId = inputData[0];
        this.docId = inputData[1];
        this.policyNo = inputData[2];
        this.cheqAmt = inputData[3];
        this.cheqAmtStart = inputData[4];
        this.cheqAmtThai = inputData[5];
        this.matchIndc = inputData[6];
        this.sourceCode = inputData[7];
        this.stateCode = inputData[8];
        this.disbTypeCode = inputData[9];
        this.dpDSk = inputData[10];
        this.bankCode = inputData[11];
        this.branchName = inputData[12];
        this.cheqDate = inputData[13];
        this.cheqDescLn1 = inputData[14];
        this.cheqDescLn2 = inputData[15];
        this.cheqDescLn3 = inputData[16];
        this.cheqDescLn4 = inputData[17];
        this.cheqPayeeTitle = inputData[18];
        this.cheqPayeeFname = inputData[19];
        this.cheqPayeeLname = inputData[20];
        this.zipCode = inputData[21];
        this.payeeAddrLn1 = inputData[22];
        this.payeeAddrLn2 = inputData[23];
        this.payeeAddrLn3 = inputData[24];
        this.payeeAddrLn4 = inputData[25];
        this.paymentType = inputData[26];
        this.prtxSeqNo = inputData[27];
        this.agencyOfficeCode1 = inputData[28];
        this.agencyCode1 = inputData[29];
        this.agencyCode2 = inputData[30];
        this.agentCode1 = inputData[31];
        this.agentCode2 = inputData[32];
        this.docSc = inputData[33];
        this.cheqRelDate = inputData[34];
        this.insuredChq = inputData[35];
        this.cheqRunningNo = inputData[36];
        this.userID1 = inputData[37];
        this.userDept1 = inputData[38];
        this.letterDate = inputData[39];
        this.insuredTitle = inputData[40];
        this.insuredName = inputData[41];
        this.insuredSuffix = inputData[42];
        this.ownerTitle = inputData[43];
        this.ownerName = inputData[44];
        this.ownerSuffix = inputData[45];
        this.ownerAddr1 = inputData[46];
        this.ownerAddr2 = inputData[47];
        this.ownerAddr3 = inputData[48];
        this.ownerAddr4 = inputData[49];
        this.corrType = inputData[50];
        this.char1 = inputData[51];
        this.char2 = inputData[52];
        this.char3 = inputData[53];
        this.char4 = inputData[54];
        this.str1 = inputData[55];
        this.str2 = inputData[56];
        this.str3 = inputData[57];
        this.str4 = inputData[58];
        this.str5 = inputData[59];
        this.str6 = inputData[60];
        this.str7 = inputData[61];
        this.str8 = inputData[62];
        this.str9 = inputData[63];
        this.lstr1 = inputData[64];
        this.lstr2 = inputData[65];
        this.lstr3 = inputData[66];
        this.lstr4 = inputData[67];
        this.dec1 = inputData[68];
        this.dec2 = inputData[69];
        this.dec3 = inputData[70];
        this.dec4 = inputData[71];
        this.dec5 = inputData[72];
        this.dec6 = inputData[73];
        this.dec7 = inputData[74];
        this.dec8 = inputData[75];
        this.dec9 = inputData[76];
        this.date1 = inputData[77];
        this.date2 = inputData[78];
        this.date3 = inputData[79];
        this.date4 = inputData[80];
        this.cheqDate2 = inputData[81];
        this.datSys = inputData[82];
        this.cheqSeqNo = inputData[83];
        this.titleIndc = inputData[84];
        this.subOfficeCode = inputData[85];
        this.payeeType = inputData[86];
        this.distributeInd = inputData[87];
        this.dec10 = inputData[88];  
        
        this.cycleDate = inputData[13];
        this.optStr = optStr;
    }    

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getCheqAmt() {
        return cheqAmt;
    }

    public void setCheqAmt(String cheqAmt) {
        this.cheqAmt = cheqAmt;
    }

    public String getCheqAmtStart() {
        return cheqAmtStart;
    }

    public void setCheqAmtStart(String cheqAmtStart) {
        this.cheqAmtStart = cheqAmtStart;
    }

    public String getCheqAmtThai() {
        return cheqAmtThai;
    }

    public void setCheqAmtThai(String cheqAmtThai) {
        this.cheqAmtThai = cheqAmtThai;
    }

    public String getMatchIndc() {
        return matchIndc;
    }

    public void setMatchIndc(String matchIndc) {
        this.matchIndc = matchIndc;
    }

    public String getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getDisbTypeCode() {
        return disbTypeCode;
    }

    public void setDisbTypeCode(String disbTypeCode) {
        this.disbTypeCode = disbTypeCode;
    }

    public String getDpDSk() {
        return dpDSk;
    }

    public void setDpDSk(String dpDSk) {
        this.dpDSk = dpDSk;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getCheqDate() {
        return cheqDate;
    }

    public void setCheqDate(String cheqDate) {
        this.cheqDate = cheqDate;
    }

    public String getCheqDescLn1() {
        return cheqDescLn1;
    }

    public void setCheqDescLn1(String cheqDescLn1) {
        this.cheqDescLn1 = cheqDescLn1;
    }

    public String getCheqDescLn2() {
        return cheqDescLn2;
    }

    public void setCheqDescLn2(String cheqDescLn2) {
        this.cheqDescLn2 = cheqDescLn2;
    }

    public String getCheqDescLn3() {
        return cheqDescLn3;
    }

    public void setCheqDescLn3(String cheqDescLn3) {
        this.cheqDescLn3 = cheqDescLn3;
    }

    public String getCheqDescLn4() {
        return cheqDescLn4;
    }

    public void setCheqDescLn4(String cheqDescLn4) {
        this.cheqDescLn4 = cheqDescLn4;
    }

    public String getCheqPayeeTitle() {
        return cheqPayeeTitle;
    }

    public void setCheqPayeeTitle(String cheqPayeeTitle) {
        this.cheqPayeeTitle = cheqPayeeTitle;
    }

    public String getCheqPayeeFname() {
        return cheqPayeeFname;
    }

    public void setCheqPayeeFname(String cheqPayeeFname) {
        this.cheqPayeeFname = cheqPayeeFname;
    }

    public String getCheqPayeeLname() {
        return cheqPayeeLname;
    }

    public void setCheqPayeeLname(String cheqPayeeLname) {
        this.cheqPayeeLname = cheqPayeeLname;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPayeeAddrLn1() {
        return payeeAddrLn1;
    }

    public void setPayeeAddrLn1(String payeeAddrLn1) {
        this.payeeAddrLn1 = payeeAddrLn1;
    }

    public String getPayeeAddrLn2() {
        return payeeAddrLn2;
    }

    public void setPayeeAddrLn2(String payeeAddrLn2) {
        this.payeeAddrLn2 = payeeAddrLn2;
    }

    public String getPayeeAddrLn3() {
        return payeeAddrLn3;
    }

    public void setPayeeAddrLn3(String payeeAddrLn3) {
        this.payeeAddrLn3 = payeeAddrLn3;
    }

    public String getPayeeAddrLn4() {
        return payeeAddrLn4;
    }

    public void setPayeeAddrLn4(String payeeAddrLn4) {
        this.payeeAddrLn4 = payeeAddrLn4;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPrtxSeqNo() {
        return prtxSeqNo;
    }

    public void setPrtxSeqNo(String prtxSeqNo) {
        this.prtxSeqNo = prtxSeqNo;
    }

    public String getAgencyOfficeCode1() {
        return agencyOfficeCode1;
    }

    public void setAgencyOfficeCode1(String agencyOfficeCode1) {
        this.agencyOfficeCode1 = agencyOfficeCode1;
    }

    public String getAgencyCode1() {
        return agencyCode1;
    }

    public void setAgencyCode1(String agencyCode1) {
        this.agencyCode1 = agencyCode1;
    }

    public String getAgencyCode2() {
        return agencyCode2;
    }

    public void setAgencyCode2(String agencyCode2) {
        this.agencyCode2 = agencyCode2;
    }

    public String getAgentCode1() {
        return agentCode1;
    }

    public void setAgentCode1(String agentCode1) {
        this.agentCode1 = agentCode1;
    }

    public String getAgentCode2() {
        return agentCode2;
    }

    public void setAgentCode2(String agentCode2) {
        this.agentCode2 = agentCode2;
    }

    public String getDocSc() {
        return docSc;
    }

    public void setDocSc(String docSc) {
        this.docSc = docSc;
    }

    public String getCheqRelDate() {
        return cheqRelDate;
    }

    public void setCheqRelDate(String cheqRelDate) {
        this.cheqRelDate = cheqRelDate;
    }

    public String getInsuredChq() {
        return insuredChq;
    }

    public void setInsuredChq(String insuredChq) {
        this.insuredChq = insuredChq;
    }

    public String getCheqRunningNo() {
        return cheqRunningNo;
    }

    public void setCheqRunningNo(String cheqRunningNo) {
        this.cheqRunningNo = cheqRunningNo;
    }

    public String getUserID1() {
        return userID1;
    }

    public void setUserID1(String userID1) {
        this.userID1 = userID1;
    }

    public String getUserDept1() {
        return userDept1;
    }

    public void setUserDept1(String userDept1) {
        this.userDept1 = userDept1;
    }

    public String getLetterDate() {
        return letterDate;
    }

    public void setLetterDate(String letterDate) {
        this.letterDate = letterDate;
    }

    public String getInsuredTitle() {
        return insuredTitle;
    }

    public void setInsuredTitle(String insuredTitle) {
        this.insuredTitle = insuredTitle;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public String getInsuredSuffix() {
        return insuredSuffix;
    }

    public void setInsuredSuffix(String insuredSuffix) {
        this.insuredSuffix = insuredSuffix;
    }

    public String getOwnerTitle() {
        return ownerTitle;
    }

    public void setOwnerTitle(String ownerTitle) {
        this.ownerTitle = ownerTitle;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerSuffix() {
        return ownerSuffix;
    }

    public void setOwnerSuffix(String ownerSuffix) {
        this.ownerSuffix = ownerSuffix;
    }

    public String getOwnerAddr1() {
        return ownerAddr1;
    }

    public void setOwnerAddr1(String ownerAddr1) {
        this.ownerAddr1 = ownerAddr1;
    }

    public String getOwnerAddr2() {
        return ownerAddr2;
    }

    public void setOwnerAddr2(String ownerAddr2) {
        this.ownerAddr2 = ownerAddr2;
    }

    public String getOwnerAddr3() {
        return ownerAddr3;
    }

    public void setOwnerAddr3(String ownerAddr3) {
        this.ownerAddr3 = ownerAddr3;
    }

    public String getOwnerAddr4() {
        return ownerAddr4;
    }

    public void setOwnerAddr4(String ownerAddr4) {
        this.ownerAddr4 = ownerAddr4;
    }

    public String getCorrType() {
        return corrType;
    }

    public void setCorrType(String corrType) {
        this.corrType = corrType;
    }

    public String getChar1() {
        return char1;
    }

    public void setChar1(String char1) {
        this.char1 = char1;
    }

    public String getChar2() {
        return char2;
    }

    public void setChar2(String char2) {
        this.char2 = char2;
    }

    public String getChar3() {
        return char3;
    }

    public void setChar3(String char3) {
        this.char3 = char3;
    }

    public String getChar4() {
        return char4;
    }

    public void setChar4(String char4) {
        this.char4 = char4;
    }

    public String getStr1() {
        return str1;
    }

    public void setStr1(String str1) {
        this.str1 = str1;
    }

    public String getStr2() {
        return str2;
    }

    public void setStr2(String str2) {
        this.str2 = str2;
    }

    public String getStr3() {
        return str3;
    }

    public void setStr3(String str3) {
        this.str3 = str3;
    }

    public String getStr4() {
        return str4;
    }

    public void setStr4(String str4) {
        this.str4 = str4;
    }

    public String getStr5() {
        return str5;
    }

    public void setStr5(String str5) {
        this.str5 = str5;
    }

    public String getStr6() {
        return str6;
    }

    public void setStr6(String str6) {
        this.str6 = str6;
    }

    public String getStr7() {
        return str7;
    }

    public void setStr7(String str7) {
        this.str7 = str7;
    }

    public String getStr8() {
        return str8;
    }

    public void setStr8(String str8) {
        this.str8 = str8;
    }

    public String getStr9() {
        return str9;
    }

    public void setStr9(String str9) {
        this.str9 = str9;
    }

    public String getLstr1() {
        return lstr1;
    }

    public void setLstr1(String lstr1) {
        this.lstr1 = lstr1;
    }

    public String getLstr2() {
        return lstr2;
    }

    public void setLstr2(String lstr2) {
        this.lstr2 = lstr2;
    }

    public String getLstr3() {
        return lstr3;
    }

    public void setLstr3(String lstr3) {
        this.lstr3 = lstr3;
    }

    public String getLstr4() {
        return lstr4;
    }

    public void setLstr4(String lstr4) {
        this.lstr4 = lstr4;
    }

    public String getDec1() {
        return dec1;
    }

    public void setDec1(String dec1) {
        this.dec1 = dec1;
    }

    public String getDec2() {
        return dec2;
    }

    public void setDec2(String dec2) {
        this.dec2 = dec2;
    }

    public String getDec3() {
        return dec3;
    }

    public void setDec3(String dec3) {
        this.dec3 = dec3;
    }

    public String getDec4() {
        return dec4;
    }

    public void setDec4(String dec4) {
        this.dec4 = dec4;
    }

    public String getDec5() {
        return dec5;
    }

    public void setDec5(String dec5) {
        this.dec5 = dec5;
    }

    public String getDec6() {
        return dec6;
    }

    public void setDec6(String dec6) {
        this.dec6 = dec6;
    }

    public String getDec7() {
        return dec7;
    }

    public void setDec7(String dec7) {
        this.dec7 = dec7;
    }

    public String getDec8() {
        return dec8;
    }

    public void setDec8(String dec8) {
        this.dec8 = dec8;
    }

    public String getDec9() {
        return dec9;
    }

    public void setDec9(String dec9) {
        this.dec9 = dec9;
    }

    public String getDate1() {
        return date1;
    }

    public void setDate1(String date1) {
        this.date1 = date1;
    }

    public String getDate2() {
        return date2;
    }

    public void setDate2(String date2) {
        this.date2 = date2;
    }

    public String getDate3() {
        return date3;
    }

    public void setDate3(String date3) {
        this.date3 = date3;
    }

    public String getDate4() {
        return date4;
    }

    public void setDate4(String date4) {
        this.date4 = date4;
    }

    public String getCheqDate2() {
        return cheqDate2;
    }

    public void setCheqDate2(String cheqDate2) {
        this.cheqDate2 = cheqDate2;
    }

    public String getDatSys() {
        return datSys;
    }

    public void setDatSys(String datSys) {
        this.datSys = datSys;
    }

    public String getCheqSeqNo() {
        return cheqSeqNo;
    }

    public void setCheqSeqNo(String cheqSeqNo) {
        this.cheqSeqNo = cheqSeqNo;
    }

    public String getTitleIndc() {
        return titleIndc;
    }

    public void setTitleIndc(String titleIndc) {
        this.titleIndc = titleIndc;
    }

    public String getSubOfficeCode() {
        return subOfficeCode;
    }

    public void setSubOfficeCode(String subOfficeCode) {
        this.subOfficeCode = subOfficeCode;
    }

    public String getPayeeType() {
        return payeeType;
    }

    public void setPayeeType(String payeeType) {
        this.payeeType = payeeType;
    }

    public String getDistributeInd() {
        return distributeInd;
    }

    public void setDistributeInd(String distributeInd) {
        this.distributeInd = distributeInd;
    }

    public String getDec10() {
        return dec10;
    }

    public void setDec10(String dec10) {
        this.dec10 = dec10;
    }
    
    public String getCycleDate() {
        return cycleDate;
    }

    public void setCycleDate(String cycleDate) {
        this.cycleDate = cycleDate;
    }
    
    public String getOptStr() {
        return optStr;
    }

    public void setOptStr(String optStr) {
        this.optStr = optStr;
    }    
    
    public List<Cheque> getListOfCheque() {
        return listOfCheque;
    }

    public void setListOfCheque(List<Cheque> listOfCheque) {
        this.listOfCheque = listOfCheque;
    }        
}
