/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aia.cws.entity;

import java.io.Serializable;

/**
 *
 * @author Krissana
 */
public class ChequeGenerateModel implements Serializable {
    private String status;
    private byte[] content;

    public ChequeGenerateModel() {
        
    }

    public ChequeGenerateModel(String status, byte[] content) {
        this.status = status;
        this.content = content;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public byte[] getContent() {
        return content;
    }

    public void setContent(byte[] content) {
        this.content = content;
    }      
}
