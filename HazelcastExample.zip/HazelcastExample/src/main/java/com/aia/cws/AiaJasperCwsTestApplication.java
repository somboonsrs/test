package com.aia.cws;

import com.aia.cws.service.GenerateReportService;
import java.lang.invoke.MethodHandles;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;

@EnableCaching
@SpringBootApplication
public class AiaJasperCwsTestApplication implements CommandLineRunner {

    private static Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Autowired
    private GenerateReportService generateReportService;

    @Autowired
    private CacheManager cacheManager;

    public static void main(String[] args) {
        SpringApplication.run(AiaJasperCwsTestApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {        
        logger.info("====== Start : Jasper CMS (Cheque) in Hazelcast ======");
        
        Temporal initTime = LocalDateTime.now();
        
        // Load cheque data to Hazelcast
        generateReportService.loadData();
        
        // Generate cheque data to PDFStream (byte[])
        generateReportService.process();  
        
        // Merge PDF reports
        generateReportService.mergePDFReport();        
        
        // Shutdown Hazelcast
        generateReportService.shutdown();
        
        logger.info("====== Finished : " + dateTimeDiff(initTime, LocalDateTime.now(), ChronoUnit.MILLIS) + " Milliseconds ======");
    }
    
    private long dateTimeDiff(Temporal tempo1, Temporal tempo2, ChronoUnit unit) {
        return unit.between(tempo1, tempo2);
    }        
}
